# 💬 Análise de Sentimentos com Azure AI Language Studio - Setor Financeiro

Projeto de exemplo para aplicar **Análise de Sentimentos** usando o **Azure AI Language Studio** com foco em avaliações e feedbacks de clientes bancários.

## 🎯 Objetivo

Utilizar o serviço de **Text Analytics** para extrair sentimento (positivo, negativo, neutro) de frases de clientes, aplicando técnicas de IA no setor financeiro.

## 📦 Recursos Usados

- Azure Language Studio
- Serviço de Cognitive Services (Text Analytics)
- Python + SDK Azure AI Text Analytics
- Dataset com frases simuladas do setor financeiro

## 📁 Estrutura

```
azure-sentiment-finance/
├── README.md
├── LICENSE
├── .gitignore
├── notebooks/
│   └── sentiment-analysis.ipynb
├── data/
│   └── feedbacks.csv
└── docs/
    └── instructions.md
```

## ▶️ Como Executar

1. Crie um recurso do tipo **Azure AI Language** no portal do Azure.
2. Obtenha a `KEY` e `ENDPOINT`.
3. Instale dependências:

```bash
pip install azure-ai-textanalytics pandas
```

4. Edite o notebook com suas chaves e execute.

## 🧠 Exemplos de Frases (data/feedbacks.csv)

- "Estou muito satisfeito com o atendimento."
- "As taxas do cartão são abusivas!"
- "Serviço razoável, mas poderia ser mais rápido."

## 🔗 Recursos

- [Lab Oficial Microsoft - Text Analysis](https://microsoftlearning.github.io/mslearn-ai-fundamentals/Instructions/Labs/06-text-analysis.html)
- [Lab Oficial Microsoft - Speech](https://microsoftlearning.github.io/mslearn-ai-fundamentals/Instructions/Labs/09-speech.html)

## 📜 Licença

MIT
