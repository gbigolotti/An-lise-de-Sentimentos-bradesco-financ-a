# Instruções para Language Studio

1. Vá até https://language.cognitive.azure.com/
2. Crie um recurso "Azure AI Language"
3. Na aba "Sentiment Analysis", cole as frases do `feedbacks.csv`
4. Teste com frases novas e analise a classificação

Para programadores: use o SDK Azure Text Analytics
